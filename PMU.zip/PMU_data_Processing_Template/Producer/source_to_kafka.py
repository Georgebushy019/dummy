import requests
import time
from kafka import KafkaProducer
import json

# Kafka setup
try:
    producer = KafkaProducer(
        bootstrap_servers='localhost:9092',  # Change this to your Kafka server
        value_serializer=lambda v: json.dumps(v).encode('utf-8')
    )
except Exception as e:
    print(f"Failed to connect to Kafka: {e}")
    exit(1)

url = "https://f531-2409-4072-317-da71-814c-2b28-f78-e5c3.ngrok-free.app/generate_data"  # Updated URL

num_rows = 1
params = {'num_rows': num_rows}  # Specify the number of rows you want

response = requests.get(url, params=params)

if response.status_code == 200:
    data = response.json()
    print("Generated data:")
    print(data)

    # Debugging: Print the type of data
    print("Type of data:", type(data))

    # Function to determine partition based on data type
    def get_partition(data_type):
        if data_type == 'current':
            return 0
        elif data_type == 'voltage':
            return 1
        elif data_type == 'phase_angle':
            return 2
        else:
            return 0  # Default to partition 0 if type is unknown

    # Send data to Kafka topic
    for row in data:
        print("Inside loop: ", row)  # Debugging: Print each row
        try:
            # Send the message to the appropriate Kafka partition
            #producer.send('sensor_data', key=b'current', value=json.dumps({'current': row['current']}), partition=get_partition('current'))
            producer.send('sensor_data', key=b'current', value=row['current'], partition=get_partition('current'))
            #producer.send('sensor_data', key=b'voltage', value=json.dumps({'voltage': row['voltage']}), partition=get_partition('voltage'))
            producer.send('sensor_data', key=b'voltage', value=row['voltage'], partition=get_partition('voltage'))
            #producer.send('sensor_data', key=b'phase_angle', value=json.dumps({'phase_angle': row['phase_angle']}), partition=get_partition('phase_angle'))
            producer.send('sensor_data', key=b'phase_angle', value=row['phase_angle'], partition=get_partition('phase_angle'))
            
            print("Message sent successfully to Kafka topics.")
            
        except Exception as e:
            print(f"Failed to send message to Kafka: {e}")

    # Ensure all messages are sent
    producer.flush()
else:
    print("Failed to fetch data. Status code:", response.status_code)


