import logging

import mlflow
import numpy as np
import pandas as pd
from model.evaluation import accuracy
from sklearn.base import ClassifierMixin
from typing_extensions import Annotated
from zenml import step
from zenml.client import Client

experiment_tracker = Client().active_stack.experiment_tracker
from typing import Tuple


# @step(experiment_tracker=experiment_tracker.name)
# def evaluation(
#     model: ClassifierMixin, x_test: pd.DataFrame, y_test: pd.Series
# ) -> Tuple[Annotated[float, "Accuracy"]]:
@step(experiment_tracker=experiment_tracker.name)
def evaluation(
    model: ClassifierMixin, x_test: pd.DataFrame, y_test: pd.Series
) -> float:
    """
    Args:
        model: ClassifierMixin
        x_test: pd.DataFrame
        y_test: pd.Series
    Returns:
        Tuple containing accuracy: float
    """
    try:

        prediction = model.predict(x_test)
        accuracy_calculator = accuracy()
        accuracy_value = accuracy_calculator.calculate_score(y_test, prediction)
        mlflow.log_metric("Accuracy", accuracy_value)
        
        return accuracy_value
    
    except Exception as e:
        logging.error(e)
        raise e