import streamlit as st
import pandas as pd
from cassandra.cluster import Cluster
import plotly.express as px

# Connect to Cassandra
cluster = Cluster(['127.0.0.1'])
session = cluster.connect('sensor_data_keyspace')

# Function to fetch data from Cassandra and convert to float
def fetch_data():
    rows = session.execute('SELECT * FROM sensor_data')
    data = []
    for row in rows:
        data.append([row.timestamp, float(row.current), float(row.voltage), float(row.phase_angle)])
    data_df = pd.DataFrame(data, columns=['Timestamp', 'Current', 'Voltage', 'Phase Angle'])
    data_df = data_df.sort_values(by='Timestamp')
    return data_df

# Function to plot charts
def plot_charts(data):
    fig1 = px.line(data, x='Timestamp', y='Current', title='Current vs. Time')
    fig2 = px.line(data, x='Timestamp', y='Voltage', title='Voltage vs. Time')
    fig3 = px.line(data, x='Timestamp', y='Phase Angle', title='Phase Angle vs. Time')
    return fig1, fig2, fig3

# Main Streamlit app
def main():
    st.title('Sensor Data Analysis')
    st.button("Update")
    
    # Fetch data from Cassandra
    data = fetch_data()
    
    # Plot charts
    if not data.empty:
        st.header('Charts')
        fig1, fig2, fig3 = plot_charts(data)
        st.plotly_chart(fig1, use_container_width=True)
        st.plotly_chart(fig2, use_container_width=True)
        st.plotly_chart(fig3, use_container_width=True)
    else:
        st.warning('No data available in the database.')

if __name__ == '__main__':
    main()
