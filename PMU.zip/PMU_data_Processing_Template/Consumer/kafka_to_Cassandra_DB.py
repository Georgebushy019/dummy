import json
from kafka import KafkaConsumer
from cassandra.cluster import Cluster
from cassandra.query import SimpleStatement
from uuid import uuid4
from datetime import datetime

# Kafka consumer setup
consumer = KafkaConsumer('sensor_data', bootstrap_servers='localhost:9092', group_id='my-group', value_deserializer=lambda v: v.decode('utf-8'))

# Cassandra setup
cluster = Cluster(['127.0.0.1'])  # Use your Cassandra node IP
session = cluster.connect()

# Use the keyspace where your sensor_data table exists
session.set_keyspace('sensor_data_keyspace')

# Prepared statement for inserting data
insert_stmt = session.prepare(
    "INSERT INTO sensor_data (timestamp, current, voltage, phase_angle) VALUES (?, ?, ?, ?)"
)

# Initialize variables to hold received data
received_data = {}

# Main loop to consume messages and insert data into Cassandra
try:
    for message in consumer:
        # Extract the data type from the message key
        timestamp = datetime.now()
        data_type = message.key.decode('utf-8')
        print(data_type)
        # Get the raw data payload
        raw_data = message.value
        print("Raw data:", raw_data)
        
        # Store the received data in the dictionary
        received_data[data_type] = raw_data
        
        # Check if all data types are present before inserting into Cassandra
        if all(field in received_data for field in ['current', 'voltage', 'phase_angle']):
            # Insert into Cassandra only when all data types are present
            session.execute(
                insert_stmt,
                (timestamp, received_data['current'], received_data['voltage'], received_data['phase_angle'])
            )
            print("Data inserted into Cassandra:", received_data)
            # Reset the received_data dictionary for the next row
            received_data = {}

except KeyboardInterrupt:
    print("Process interrupted. Exiting...")
finally:
    # Close the Kafka consumer
    consumer.close()
    # Close the Cassandra session
    cluster.shutdown()
