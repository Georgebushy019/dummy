# import json
# from kafka import KafkaConsumer
# import csv

# # Kafka consumer setup
# consumer = KafkaConsumer('sensor_data', bootstrap_servers='localhost:9092', group_id='my-group', value_deserializer=lambda v: v.decode('utf-8'))

# # CSV file setup
# csv_file = '/app/ML/data/data_from_kafka.csv'
# csv_columns = ['current', 'voltage', 'phase_angle']

# # Initialize buffer to store data for each row
# data_buffer = {column: None for column in csv_columns}

# # Main loop to consume messages and write to CSV file
# try:
#     with open(csv_file, 'a', newline='') as file:
#         writer = csv.DictWriter(file, fieldnames=csv_columns)
#         file_empty = file.tell() == 0  # Check if file is empty
        
#         if file_empty:  # Write header only if file is empty
#             # Check if any column name is empty
#             if any(not column for column in csv_columns):
#                 print("Invalid column names. Aborting CSV creation.")
#             else:
#                 writer.writeheader()
#                 print("CSV file created with headers:", csv_columns)
        
#         for message in consumer:
#             # Extract the data type from the message key
#             data_type = message.key.decode('utf-8')
#             print(data_type)
#             # Get the raw data payload
#             raw_data = message.value
#             print("Raw data:", raw_data)
            
#             # Fill data dictionary based on data type
#             if data_type == 'current':
#                 data_buffer['current'] = raw_data
#             elif data_type == 'voltage':
#                 data_buffer['voltage'] = raw_data
#             elif data_type == 'phase_angle':
#                 data_buffer['phase_angle'] = raw_data
#             else:
#                 print("Unknown data type:", data_type)
#                 continue
            
#             # If all data types are present, write row to CSV
#             if all(data_buffer.values()):
#                 writer.writerow(data_buffer)
#                 file.flush()  # Flush the buffer to ensure data is written immediately
#                 print("Data written to CSV:", data_buffer)
#                 # Reset the buffer for the next row
#                 data_buffer = {column: None for column in csv_columns}

# except KeyboardInterrupt:
#     print("Process interrupted. Exiting...")
# finally:
#     # Close the Kafka consumer
#     consumer.close()
import json
from kafka import KafkaConsumer
import csv
import time
from datetime import datetime, timedelta
import random

# Kafka consumer setup
consumer = KafkaConsumer('sensor_data', bootstrap_servers='localhost:9092', group_id='my-group', value_deserializer=lambda v: v.decode('utf-8'))

# CSV file setup
csv_file = '/app/ML/data/data_from_kafka.csv'
csv_columns = ['current', 'voltage', 'phase_angle']

# Initialize buffer to store data for each row
data_buffer = {column: None for column in csv_columns}

# Set up the initial time for dumping data every 58 minutes
dump_interval = timedelta(minutes=58)
last_dump_time = datetime.now()

# Function to get the next dump interval with a small random adjustment
def get_next_dump_interval():
    random_adjustment = random.randint(1, 120)  # Random adjustment between 1 and 120 seconds
    return dump_interval + timedelta(seconds=random_adjustment)

# Initialize the next dump interval
next_dump_interval = get_next_dump_interval()

# Main loop to consume messages and write to CSV file
try:
    with open(csv_file, 'a', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=csv_columns)
        file_empty = file.tell() == 0  # Check if file is empty
        
        if file_empty:  # Write header only if file is empty
            # Check if any column name is empty
            if any(not column for column in csv_columns):
                print("Invalid column names. Aborting CSV creation.")
            else:
                writer.writeheader()
                print("CSV file created with headers:", csv_columns)
        
        for message in consumer:
            # Extract the data type from the message key
            data_type = message.key.decode('utf-8')
            print(data_type)
            # Get the raw data payload
            raw_data = message.value
            print("Raw data:", raw_data)
            
            # Fill data dictionary based on data type
            if data_type == 'current':
                data_buffer['current'] = raw_data
            elif data_type == 'voltage':
                data_buffer['voltage'] = raw_data
            elif data_type == 'phase_angle':
                data_buffer['phase_angle'] = raw_data
            else:
                print("Unknown data type:", data_type)
                continue
            
            # If all data types are present, write row to CSV
            if all(data_buffer.values()):
                writer.writerow(data_buffer)
                file.flush()  # Flush the buffer to ensure data is written immediately
                print("Data written to CSV:", data_buffer)
                # Reset the buffer for the next row
                data_buffer = {column: None for column in csv_columns}
            
            # Check if the time interval for dumping data has passed
            current_time = datetime.now()
            if current_time - last_dump_time >= next_dump_interval:
                print("Dumping data to CSV file after interval")
                file.flush()  # Ensure all data is written to disk
                last_dump_time = current_time  # Reset the timer
                next_dump_interval = get_next_dump_interval()  # Calculate the next dump interval

except KeyboardInterrupt:
    print("Process interrupted. Exiting...")
finally:
    # Close the Kafka consumer
    consumer.close()
